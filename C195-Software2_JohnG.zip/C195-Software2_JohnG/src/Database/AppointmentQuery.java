package Database;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointment;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Appointment Query
 *
 * @author
 * John Gutierrez
 */
public class AppointmentQuery {

    /**
     * Converts Time to UTC in database.
     * @param dateTime
     * @return utcOutput
     */
    public static String estToUTC(String dateTime) {

        Timestamp timeStampNow = Timestamp.valueOf(dateTime);
        LocalDateTime localDateTime = timeStampNow.toLocalDateTime();
        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC"));
        String utcOutput = zonedDateTime.format(DateTimeFormatter.ofPattern("yyy-MM-dd HH:mm:ss"));
        return utcOutput;
    }

    /**
     * getAllAppointments ObservableList for appointments in database
     * @return listOfAllAppointments
     * @throws SQLException
     */
    public static ObservableList<Appointment> getAllAppointments() throws SQLException {

        ObservableList<Appointment> listOfAllAppointments = FXCollections.observableArrayList();
        String sql = "SELECT * FROM appointments as a LEFT OUTER JOIN contacts as c ON a.Contact_ID = c.Contact_ID;";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Integer appointmentID = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String appointmentType = rs.getString("Type");
                LocalDateTime startDateTime = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime endDateTime = rs.getTimestamp("End").toLocalDateTime();
                Timestamp createdDate = rs.getTimestamp("Create_Date");
                Timestamp lastUpdateDateTime = rs.getTimestamp("Last_Update");
                Integer customerID = rs.getInt("Customer_ID");
                Integer userID = rs.getInt("User_ID");
                Integer contactID = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");
                String contactEmail = rs.getString("Email");

                Appointment newAppointment = new Appointment(appointmentID, title, description, location, appointmentType,
                        startDateTime, endDateTime, createdDate, lastUpdateDateTime, customerID, userID, contactID, contactName, contactEmail);

                listOfAllAppointments.add(newAppointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listOfAllAppointments;
    }

    /**
     * Gets data from form and inserts it into the appointment database
     * @param inputTitle
     * @param inputDescription
     * @param inputLocation
     * @param inputType
     * @param inputStart
     * @param inputEnd
     * @param inputCustomerID
     * @param inputUserID
     * @param inputContactID
     * @return rowsAffected
     * @throws SQLException
     */
    public static int addAppointment(String inputTitle, String inputDescription, String inputLocation, String inputType, String inputStart, String inputEnd, Integer inputCustomerID, Integer inputUserID, Integer inputContactID) throws SQLException {

        String sql = "INSERT INTO appointments " +
                "(Title, Description, Location, Type, Start, End, Create_date, \n" +
                "Created_By, Last_Update, Last_Updated_By, Customer_ID, User_ID, Contact_ID)\n" +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setString(1, inputTitle);
        ps.setString(2, inputDescription);
        ps.setString(3, inputLocation);
        ps.setString(4, inputType);
        ps.setString(5, String.valueOf(Timestamp.valueOf(inputStart)));
        ps.setString(6, String.valueOf(Timestamp.valueOf(inputEnd)));
        ps.setString(7, String.valueOf(Timestamp.valueOf(LocalDateTime.now())));
        ps.setString(8, "user");
        ps.setString(9, String.valueOf(Timestamp.valueOf(LocalDateTime.now())));
        ps.setString(10, "user");
        ps.setInt(11, inputCustomerID);
        ps.setInt(12, inputUserID);
        ps.setInt(13, inputContactID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * Gets data from form and Updates it into the appointment database
     * @param inputApptID
     * @param inputTitle
     * @param inputDescription
     * @param inputLocation
     * @param inputType
     * @param inputStart
     * @param inputEnd
     * @param inputCustomerID
     * @param inputUserID
     * @param inputContactID
     * @return rowsAffected
     * @throws SQLException
     */
    public static int updateAppointment(Integer inputApptID, String inputTitle, String inputDescription, String inputLocation, String inputType, String inputStart, String inputEnd, Integer inputCustomerID, Integer inputUserID, Integer inputContactID) throws SQLException {

        String sql = "UPDATE appointments "
                + "SET Title=?, Description=?, Location=?, Type=?, Start=?, End=?, Last_Update=?,Last_Updated_By=?, " +
                "Customer_ID=?, User_ID=?, Contact_ID=? WHERE Appointment_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setString(1,inputTitle);
        ps.setString(2, inputDescription);
        ps.setString(3, inputLocation);
        ps.setString(4, inputType);
        ps.setString(5, String.valueOf(Timestamp.valueOf(inputStart)));
        ps.setString(6, String.valueOf(Timestamp.valueOf(inputEnd)));
        ps.setString(7, String.valueOf(Timestamp.valueOf(LocalDateTime.now())));
        ps.setString(8, "user");
        ps.setInt(9, inputCustomerID);
        ps.setInt(10, inputUserID);
        ps.setInt(11, inputContactID);
        ps.setInt(12, inputApptID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * deletes data that user chose and deletes is from appointment database
     * @param customerID
     * @return
     * @throws SQLException
     */
    public static int deleteAppointment(Integer customerID) throws SQLException {

        String sql = "DELETE FROM appointments WHERE Appointment_ID = ?";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setInt(1, customerID);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Counts Amount of appointments tied to a customer
     * @param customerID
     * @return countCustomerToAppt
     * @throws SQLException
     */
    public static int countCustomerAppointment(int customerID) throws SQLException {

        String sql = "SELECT COUNT(*) AS customerToAppt FROM appointments WHERE Customer_ID  = ?";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setInt(1, customerID);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("customerToAppt");
                } else {
                    return 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customerID;
    }
}
