package Database;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Contact;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Contact Query
 *
 * @author
 * John Gutierrez
 */
public class ContactQuery {
    /**
     * Able to grab contact names and obtains the ID for the appointment forms
     * @param contactName
     * @return contactID
     * @throws SQLException
     */
    public static Integer getContactID(String contactName) throws SQLException {
        Integer contactID = -1;
        String sql = "SELECT Contact_ID FROM contacts WHERE Contact_Name = ?";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setString(1, contactName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    contactID = rs.getInt("Contact_ID");
                }
            }
        }
        return contactID;
    }

    /**
     * getAllContacts ObservableList for Contacts in database
     * @return allContacts
     * @throws SQLException
     */

    public static ObservableList<Contact> getAllContacts() throws SQLException {

        ObservableList<Contact> allContacts = FXCollections.observableArrayList();
        String sql = "SELECT * from contacts";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int contactID = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");
                String contactEmail = rs.getString("Email");
                Contact contact = new Contact(contactID, contactName, contactEmail);
                allContacts.add(contact);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allContacts;
    }
}
