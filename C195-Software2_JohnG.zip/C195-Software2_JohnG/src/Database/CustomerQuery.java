package Database;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customer;

import java.sql.*;
import java.time.LocalDateTime;

/**
 * Customer Query
 *
 * @author
 * John Gutierrez
 */
public class CustomerQuery {

    /**
     * Grabs the IDs for customers and Loads contact data into the combo boxes
     * @return
     * @throws SQLException
     */
    public static ObservableList<Integer> getAllCustomerID() throws SQLException {

        ObservableList<Integer> allCustomerID = FXCollections.observableArrayList();
        String sql = "SELECT Customer_ID FROM customers GROUP BY Customer_ID";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                allCustomerID.add(rs.getInt("Customer_ID"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allCustomerID;

    }

    /**
     * Gets data from form and inserts it into the Customer database
     * @param customerName
     * @param address
     * @param postalCode
     * @param phone
     * @param divisionID
     * @return rowsAffected
     * @throws SQLException
     */
    public static int insertCustomer(String customerName, String address, String postalCode, String phone, Integer divisionID) throws SQLException{

        String sql = "INSERT INTO CUSTOMERS (Customer_Name, Address, Postal_Code, phone, Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setString(1, customerName);
            ps.setString(2, address);
            ps.setString(3, postalCode);
            ps.setString(4, phone);
            ps.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
            ps.setString(6, "user");
            ps.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
            ps.setString(8, "user");
            ps.setInt(9, divisionID);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Able to grab Division and obtains the ID
     * @param division
     * @return divisionID
     * @throws SQLException
     */
    public static Integer getDivisionID(String division) throws SQLException {

        Integer divisionID = 0;
        String sql = "SELECT Division_ID FROM first_level_divisions WHERE Division = ?";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setString(1, division);
            try (ResultSet result = ps.executeQuery()) {
                if (result.next()) {
                    divisionID = result.getInt(1);
                }
            }
        }
        return divisionID;
    }

    /**
     * Grabs Customers from database
     * @return allCustomers
     * @throws SQLException
     */
    public static ObservableList<Customer> getAllCustomers() throws SQLException {

        ObservableList<Customer> allCustomers = FXCollections.observableArrayList();

        String sql = "SELECT customer.Customer_ID, customer.Customer_Name, customer.Address, country.Country, firstlvldiv.Division," +
                "customer.Postal_Code, customer.Phone, customer.Division_ID, firstlvldiv.COUNTRY_ID FROM customers as customer INNER JOIN first_level_divisions " +
                "as firstlvldiv on customer.Division_ID = firstlvldiv.Division_ID INNER JOIN countries as country ON firstlvldiv.COUNTRY_ID = country.Country_ID";

        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Integer customerID = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String customerAddress = rs.getString("Address");
                String customerCountry = rs.getString("Country");
                String customerDivision = rs.getString("Division");
                String customerPostalCode = rs.getString("Postal_Code");
                String customerPhoneNum = rs.getString("Phone");
                Integer divisionID = rs.getInt("Division_ID");

                Customer newCustomer = new Customer(customerID, customerName, customerAddress, customerCountry, customerDivision, customerPostalCode, customerPhoneNum, divisionID);

                allCustomers.add(newCustomer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return allCustomers;

    }

    /**
     * Grabs country and ties it to its correct division
     * @param inputCountry
     * @return firstLevelDivisionsByCountry
     * @throws SQLException
     */
    public static ObservableList<String> getFirstLevelDivisionsByCountry(String inputCountry) throws SQLException {

        ObservableList<String> firstLevelDivisionsByCountry = FXCollections.observableArrayList();

        String sql = "SELECT firstlvldiv.Division FROM countries AS c INNER JOIN " +
                "first_level_divisions AS firstlvldiv ON c.Country_ID = firstlvldiv.Country_ID WHERE c.Country = ?";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setString(1, inputCountry);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    firstLevelDivisionsByCountry.add(rs.getString("Division"));
                }
            }
        }
        return firstLevelDivisionsByCountry;
    }

    /**
     * Grabs Countries from database
     * @return
     * @throws SQLException
     */
    public static ObservableList<String> getAllCountries() throws SQLException {

        ObservableList<String> listOfAllCountries = FXCollections.observableArrayList();
        String sql = "SELECT DISTINCT Country FROM countries";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                listOfAllCountries.add(rs.getString("Country"));
            }
        }
        return listOfAllCountries;
    }

    /**
     * Gets data from form and Updates it into the Customer database
     * @param division
     * @param name
     * @param address
     * @param postalCode
     * @param phoneNum
     * @param customerID
     * @return rowsAffected
     * @throws SQLException
     */
    public static int updateCustomer(String name, String address, String postalCode, String phoneNum, String division, Integer customerID) throws SQLException {

        String sql = "UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Last_Update = ?, Last_Updated_By = ?, Division_ID = ? WHERE Customer_ID = ?";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, address);
            ps.setString(3, postalCode);
            ps.setString(4, phoneNum);
            ps.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
            ps.setString(6, "user");
            ps.setInt(7, CustomerQuery.getDivisionID(division));
            ps.setInt(8, customerID);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * deletes data that user chose and deletes is from Customer database
     * @param customerID
     * @return rowsAffected
     * @throws SQLException
     */
    public static int deleteCustomer(Integer customerID) throws SQLException {

        String sql = "DELETE FROM CUSTOMERS WHERE Customer_ID = ?";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setInt(1, customerID);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
