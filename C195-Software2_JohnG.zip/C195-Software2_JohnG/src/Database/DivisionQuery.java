package Database;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FirstLevelDivision;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Division Query
 *
 * @author
 * John Gutierrez
 */
public class DivisionQuery extends FirstLevelDivision{
    /**
     *
     * @param divisionID
     * @param divisionName
     * @param country_ID
     */
    public DivisionQuery(int divisionID, String divisionName, int country_ID) {
        super(divisionID, divisionName, country_ID);
    }

    /**
     * Grabs all the first level divisions from the database
     * @return
     * @throws SQLException
     */
    public static ObservableList<DivisionQuery> getAllFirstLevelDivisions() throws SQLException {

        ObservableList<DivisionQuery> allFirstLevelDivisions = FXCollections.observableArrayList();

        String sql = "SELECT * from first_level_divisions";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int countryID = rs.getInt("country_ID");

                DivisionQuery divisionQuery = new DivisionQuery(divisionID, divisionName, countryID);
                allFirstLevelDivisions.add(divisionQuery);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allFirstLevelDivisions;
    }
}
