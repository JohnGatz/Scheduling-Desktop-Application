package Database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Login Query
 *
 * @author
 * John Gutierrez
 */
public class LoginQuery {

    /**
     * Make sure login is valid
     * @param username
     * @param password
     * @return
     */
    public static int loginIsValid(String username, String password)
    {
        String sql = "SELECT * FROM users WHERE user_name = ? AND password = ?";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("User_ID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

}
