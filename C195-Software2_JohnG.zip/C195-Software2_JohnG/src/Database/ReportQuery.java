package Database;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointment;
import model.ReportByCountry;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * ReportForm Query
 *
 * @author
 * John Gutierrez
 */
public class ReportQuery extends Appointment {
    /**
     *
     * @param appointmentID
     * @param title
     * @param description
     * @param location
     * @param appointmentType
     * @param startDateTime
     * @param endDateTime
     * @param createDate
     * @param lastUpdateDateTime
     * @param customerID
     * @param userID
     * @param contactID
     * @param contactName
     * @param contactEmail
     */
    public ReportQuery(Integer appointmentID, String title, String description, String location, String appointmentType, LocalDateTime startDateTime, LocalDateTime endDateTime, Timestamp createDate, Timestamp lastUpdateDateTime, Integer customerID, Integer userID, Integer contactID, String contactName, String contactEmail) {
        super(appointmentID, title, description, location, appointmentType, startDateTime, endDateTime, createDate, lastUpdateDateTime, customerID, userID, contactID, contactName, contactEmail);
    }

    /**
     * Grabs the Country and counts how many appointments are in that country
     * @return
     * @throws SQLException
     */
    public static ObservableList<ReportByCountry> getAllCountries() throws SQLException {

        ObservableList<ReportByCountry> allCountries = FXCollections.observableArrayList();
        String sql = "SELECT countries.Country, COUNT(*) AS countryCount FROM customers "
                + "INNER JOIN first_level_divisions as firstlvldiv ON customers.Division_ID = firstlvldiv.Division_ID "
                + "INNER JOIN countries ON countries.Country_ID = firstlvldiv.Country_ID "
                + "GROUP BY countries.Country "
                + "ORDER BY COUNT(*) DESC";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String countryName = rs.getString("Country");
                int countryCount = rs.getInt("countryCount");
                ReportByCountry reportByCountry = new ReportByCountry(countryName, countryCount);
                allCountries.add(reportByCountry);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allCountries;
    }
}
