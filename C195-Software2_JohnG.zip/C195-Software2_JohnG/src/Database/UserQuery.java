package Database;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * User Query
 *
 * @author
 * John Gutierrez
 */
public class UserQuery {

    /**
     * Grabs all Users ID From Database
     * @return
     * @throws SQLException
     */
    public static ObservableList<Integer> getAllUserID() throws SQLException {

        ObservableList<Integer> allUserID = FXCollections.observableArrayList();
        String sql = "SELECT DISTINCT User_ID FROM users;";
        try (PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next() ) {
                allUserID.add(rs.getInt("User_ID"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allUserID;
    }
}
