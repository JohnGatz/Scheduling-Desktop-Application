package controller;

import Database.CountryQuery;
import Database.DivisionQuery;
import Database.JDBC;
import Database.CustomerQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;

/**
 * Controller for AddCustomer
 * Adds customer to the database after saving it will return to main screen
 *
 *
 * @author
 * John Gutierrez
 */

public class AddCustomer {

    @FXML
    private TextField customerIDTextField;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField addressTextField;

    @FXML
    private ComboBox<String> countryComboBox;

    @FXML
    private ComboBox<String> stateComboBox;

    @FXML
    private TextField postalCodeTextField;

    @FXML
    private TextField phoneTextField;

    Stage stage;
    Parent scene;

    /**
     * Starts adding data into the comboboxes in the customer form
     *  | lambda is used to loop through a list of countries
     *  | lambda is used to loop through a list of First lvl Divisions
     * @throws SQLException
     */
    public void initialize() throws SQLException {

        ObservableList<Country> listOfAllCountries = CountryQuery.getAllCountries();
        ObservableList<String> listOfCountryNames = FXCollections.observableArrayList();

        // lambda
        listOfAllCountries.forEach(country -> listOfCountryNames.add(country.getCountryName()));

        countryComboBox.setItems(listOfCountryNames);
        countryComboBox.setEditable(true);
        countryComboBox.getEditor().setEditable(false);

        ObservableList<DivisionQuery> listOfFirstLvlDiv = DivisionQuery.getAllFirstLevelDivisions();
        ObservableList<String> listOfFirstLvlDivNames = FXCollections.observableArrayList();

        // lambda
        listOfFirstLvlDiv.forEach(firstLevelDivision -> listOfFirstLvlDivNames.add(firstLevelDivision.getDivision()));

        stateComboBox.setItems(listOfFirstLvlDivNames);
        stateComboBox.setEditable(true);
        stateComboBox.getEditor().setEditable(false);
    }

    /**
     * Country Combobox changes the First Level Divisions depending on which Country the user chooses
     * | lambda going through firstlvlDivs and getting countryID and division for each object and adding them into 3 different list based on country ID
     * @param event
     */
    public void onActionCountryDropDown(ActionEvent event){
        try {
            JDBC.openConnection();
            ObservableList<String> firstLvlDivCountryUS = FXCollections.observableArrayList();
            ObservableList<String> firstLvlDivCountryUK = FXCollections.observableArrayList();
            ObservableList<String> firstLvlDivCountryCanada = FXCollections.observableArrayList();
            ObservableList<DivisionQuery> listOfAllFirstLvlDivs = DivisionQuery.getAllFirstLevelDivisions();

            String selectedCountry = countryComboBox.getSelectionModel().getSelectedItem();
            //lambda
            listOfAllFirstLvlDivs.forEach(firstLevelDivision -> {
                int countryId = firstLevelDivision.getCountryID();
                String division = firstLevelDivision.getDivision();
                switch (countryId) {
                    case 1:
                        firstLvlDivCountryUS.add(division);
                        break;
                    case 2:
                        firstLvlDivCountryUK.add(division);
                        break;
                    case 3:
                        firstLvlDivCountryCanada.add(division);
                        break;
                    default:
                        break;
                }
            });

            switch (selectedCountry) {
                case "U.S":
                    stateComboBox.setItems(firstLvlDivCountryUS);
                    System.out.println("U.S is Selected");
                    break;
                case "UK":
                    stateComboBox.setItems(firstLvlDivCountryUK);
                    System.out.println("UK is Selected");
                    break;
                case "Canada":
                    stateComboBox.setItems(firstLvlDivCountryCanada);
                    System.out.println("Canada is Selected");
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * On Action adds the data into the database and returns to the main screen
     * If anything on form is empty display error message
     * @param event
     */
    public void onActionSave(ActionEvent event) {

        try {
            String name = nameTextField.getText();
            String address = addressTextField.getText();
            String country = countryComboBox.getValue();
            String division = stateComboBox.getValue();
            String postalCode = postalCodeTextField.getText();
            String phone = phoneTextField.getText();

            if (name.isEmpty() || address.isEmpty() || country.isEmpty() || division.isEmpty() ||  postalCode.isEmpty() || phone.isEmpty()) {
                dialogBox(2);
            }
            else{
                int rowsAffected = CustomerQuery.insertCustomer(name, address, postalCode, phone, CustomerQuery.getDivisionID(division));
                stage = (Stage)((Button)event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();

                if(rowsAffected > 0){
                    System.out.println("Insert Successful");
                }
                else System.out.println("Insert Failed");
            }
        }
        catch(Exception e) {
            dialogBox(3);
        }


    }

    /**
     * On action if user presses the cancel button it will need to confirm it if yes it will return to main screen,
     * if no it will notify user that application did not exit.
     * @param event
     * @throws IOException
     */
    public void onActionCancel(ActionEvent event) throws IOException {

        Alert alertConfirm = new Alert(Alert.AlertType.CONFIRMATION);
        alertConfirm.setTitle("Alert");
        alertConfirm.setHeaderText(null);
        alertConfirm.setContentText("Are you sure? This will cancel all fields and return to the Main Screen.");
        Optional<ButtonType> result = alertConfirm.showAndWait();

        if(result.get() == ButtonType.OK){
            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }
        else if(result.get() == ButtonType.CANCEL){
            dialogBox(1);
        }
    }

    /**
     * Displays dialog when method is called using the id.
     * @param dialogType
     */
    private void dialogBox(int dialogType) {
        Alert alertInfo = new Alert(Alert.AlertType.INFORMATION);
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        if (dialogType == 1) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText("Program did not Exit.");
            alertInfo.showAndWait();
        }
        if (dialogType == 2) {
            alertInfo.setTitle("Error");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText("Cannot leave fields blank.");
            alertInfo.showAndWait();
        }if (dialogType == 3) {
            alertError.setTitle("Error");
            alertError.setHeaderText("Unable to add Customer");
            alertError.setContentText("Invalid values in text fields please revise.");
            alertError.showAndWait();
        }
    }
}
