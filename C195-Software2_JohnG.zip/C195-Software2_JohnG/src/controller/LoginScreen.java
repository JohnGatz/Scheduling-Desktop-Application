package controller;

import Database.AppointmentQuery;
import Database.LoginQuery;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.*;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller for LoginScreen
 * Startup Screen for user it will Validate login and after login is validated it will take user to the main screen
 *
 * @author
 * John Gutierrez
 */

public class LoginScreen implements Initializable {

    @FXML
    private Label usernameLabel;

    @FXML
    private Label passwordLabel;

    @FXML
    private Button loginButtonLabel;

    @FXML
    private Button exitButtonLabel;

    @FXML
    private Text locationLabel;

    @FXML
    private TextField usernameTextField;
    @FXML
    private TextField passwordTextField;

    @FXML
    private Label userLocationIDTextField;


    Stage stage;
    Parent scene;

    /**
     * Starts the application with the language the user is currently using in the computers settings
     * Also Displays the users current location
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //users location
        ZoneId zone = ZoneId.systemDefault();
        userLocationIDTextField.setText(String.valueOf(zone));

        Locale locale = Locale.getDefault();
        ResourceBundle rb = ResourceBundle.getBundle("Language/Login", locale);

        if(Locale.getDefault().getLanguage().equals("en") || Locale.getDefault().getLanguage().equals("fr")){
            usernameLabel.setText(rb.getString("username"));
            usernameTextField.setPromptText(rb.getString("username"));
            passwordLabel.setText(rb.getString("password"));
            passwordTextField.setPromptText(rb.getString("password"));
            loginButtonLabel.setText(rb.getString("login"));
            exitButtonLabel.setText(rb.getString("exit"));
            locationLabel.setText(rb.getString("location"));
            System.out.println(rb.getString("username") + " " + rb.getString(("password")));
        }
    }

    /**
     * Logs user in if Username and password is correct if there is an error it will give a message
     * Even if correct or incorrect Application will log what the user types in the username and password form
     * it will also log what time the user try to log in at into a separate file called login_activity.txt
     * @param event
     * @throws IOException
     * @throws SQLException
     */
    public void onActionLogin(ActionEvent event) throws IOException, SQLException {

        try (FileWriter fileWriter = new FileWriter("login_activity.txt", true);
             PrintWriter printWriter = new PrintWriter(fileWriter)) {

            String loginUsername = usernameTextField.getText();
            String loginPassword = passwordTextField.getText();

            int formIsValid = LoginQuery.loginIsValid(loginUsername, loginPassword);

            if (loginUsername.isEmpty() || loginPassword.isEmpty()) {
                System.out.println(formIsValid + " 1");
                dialogBox(2);
            } else if (formIsValid < 0) {
                System.out.println(formIsValid + " 2");
                printWriter.print(loginUsername + " has failed to log in. Date/Time:" + Timestamp.valueOf(LocalDateTime.now()) + "\n");
                dialogBox(3);
            } else if (formIsValid > 0) {
                System.out.println(formIsValid + " 3");
                printWriter.print(loginUsername + " has successfully logged in. Time:" + Timestamp.valueOf(LocalDateTime.now()) + "\n");
                dialogBox(4);
                upcomingAppointments();
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Application will notify user if there is an upcoming appointment in the next 15 mins
     * if no appointment is in the next 15 mins it will display no upcoming appointments
     * @throws SQLException
     */
    public void upcomingAppointments() throws SQLException {

        ObservableList<Appointment> getAllAppointments = AppointmentQuery.getAllAppointments();
        LocalDateTime dateTimeAfter15Minutes = LocalDateTime.now().plusMinutes(15);

        Appointment appointmentFound = null;

        for (Appointment appointment : getAllAppointments) {
            LocalDateTime startDateTime = appointment.getStartDateTime();
            if (startDateTime.isAfter(LocalDateTime.now()) && startDateTime.isBefore(dateTimeAfter15Minutes)) {
                appointmentFound = appointment;
                break;
            }
        }
        if (appointmentFound != null) {
            ResourceBundle rb = ResourceBundle.getBundle("Language/Login", Locale.getDefault());
            Alert alertInfo = new Alert(Alert.AlertType.INFORMATION);
            alertInfo.setTitle("Alert");
            alertInfo.setHeaderText(null);
            alertInfo.setContentText(rb.getString("upcomingAppointment") + "\n" + rb.getString("customer") + appointmentFound.getAppointmentID() + "\n" + rb.getString("appointmentDateTime") + appointmentFound.getStartDateTime());
            alertInfo.showAndWait();
        } else {
            dialogBox(5);
        }

    }

    /**
     * On action user will exit application
     * @param actionEvent
     */
    public void onActionExit(ActionEvent actionEvent) {
        ResourceBundle rb = ResourceBundle.getBundle("Language/Login", Locale.getDefault());
        Alert alertConfirm = new Alert(Alert.AlertType.CONFIRMATION);
        alertConfirm.setTitle(rb.getString("alert"));
        alertConfirm.setHeaderText(null);
        alertConfirm.setContentText(rb.getString("exitCon"));
        Optional<ButtonType> result = alertConfirm.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            System.exit(0);
        }
        else if(result.get() == ButtonType.CANCEL){
            dialogBox(1);
        };
    }

    /**
     * Displays dialog when method is called using the id.
     * @param dialogType
     */
    private void dialogBox(int dialogType) {
        Alert alertInfo = new Alert(Alert.AlertType.INFORMATION);
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        ResourceBundle rb = ResourceBundle.getBundle("Language/Login", Locale.getDefault());
        if (dialogType == 1) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText(rb.getString("programExit"));
            alertInfo.showAndWait();
        }if (dialogType == 2) {
            alertError.setTitle(rb.getString("error"));
            alertError.setHeaderText(null);
            alertError.setHeaderText(rb.getString("blank"));
            alertError.showAndWait();
        }if (dialogType == 3) {
            alertError.setTitle(rb.getString("error"));
            alertError.setHeaderText(rb.getString("unableToLogin"));
            alertError.setContentText(rb.getString("invalid"));
            alertError.showAndWait();
        }if (dialogType == 4) {
            alertInfo.setTitle(rb.getString("success"));
            alertInfo.setHeaderText(rb.getString("success"));
            alertInfo.setContentText(rb.getString("loginSuccessful"));
            alertInfo.showAndWait();
        }if (dialogType == 5) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText(rb.getString("noUpcomingAppointment"));
            alertInfo.showAndWait();
        }
    }
}


