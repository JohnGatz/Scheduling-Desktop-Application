package controller;

import Database.AppointmentQuery;
import Database.CustomerQuery;
import Database.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller for MainScreen
 * Main screen Where User can view Customer and Appointment tables user will be navigated to the appropriate screen for
 * add and update and user is able to delete both customers and appointment from main screen
 *
 * @author
 * John Gutierrez
 */

public class MainScreen implements Initializable {

    @FXML
    TableView<Customer> customerTable;

    @FXML
    private TableColumn<Customer, Integer> customerTableCustomerID;

    @FXML
    private TableColumn<Customer, String> customerTableName;

    @FXML
    private TableColumn<Customer, String> customerTableAddress;

    @FXML
    private TableColumn<Customer, String> customerTableCountry;

    @FXML
    private TableColumn<Customer, String> customerTableDivision;

    @FXML
    private TableColumn<Customer, String> customerTablePostalCode;

    @FXML
    private TableColumn<Customer, String> customerTablePhone;

    @FXML
    private RadioButton allRadioButton;

    @FXML
    private RadioButton monthRadioButton;

    @FXML
    private RadioButton weekRadioButton;

    @FXML
    TableView<Appointment> appointmentTable;

    @FXML
    private TableColumn<Customer, Integer> appointmentTableAppointmentID;

    @FXML
    private TableColumn<Customer, String> appointmentTableTitle;

    @FXML
    private TableColumn<Customer, String> appointmentTableDescription;

    @FXML
    private TableColumn<Customer, String> appointmentTableLocation;

    @FXML
    private TableColumn<Customer, String> appointmentTableContactName;

    @FXML
    private TableColumn<Customer, String> appointmentTableContactEmail;

    @FXML
    private TableColumn<Customer, String> appointmentTableType;

    @FXML
    private TableColumn<Customer, String> appointmentTableStart;

    @FXML
    private TableColumn<Customer, String> appointmentTableEnd;

    @FXML
    private TableColumn<Customer, String> appointmentTableCustomerID;

    @FXML
    private TableColumn<Customer, String> appointmentTableUserID;

    Customer selectedCustomer;


    Stage stage;
    Parent scene;

    /**
     * Starts both Customer and appointment tables and loads the data into them
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        ObservableList<Appointment> listOfAllAppointments;

        try {
            customerTable(CustomerQuery.getAllCustomers());
            listOfAllAppointments = AppointmentQuery.getAllAppointments();
            appointmentTable(listOfAllAppointments);
        }
        catch (SQLException e){
            e.printStackTrace();
            JDBC.openConnection();
        }

    }

    /**
     * On action takes user to the reports Screen
     * @param event
     * @throws IOException
     */
    public void onActionReportScreen(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Reports.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     *Loads customer table with any data that has been added or modified
     * @param inputList
     */
    public void customerTable(ObservableList<Customer> inputList){
        customerTable.setItems(inputList);
        customerTableCustomerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        customerTableName.setCellValueFactory(new PropertyValueFactory<>("name"));
        customerTableAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        customerTableCountry.setCellValueFactory(new PropertyValueFactory<>("country"));
        customerTableDivision.setCellValueFactory(new PropertyValueFactory<>("division"));
        customerTablePostalCode.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        customerTablePhone.setCellValueFactory(new PropertyValueFactory<>("phone"));

    }

    /**
     * Loads Appointment table with any data that has been added or modified
     * @param inputList
     */
    public void appointmentTable(ObservableList<Appointment> inputList){
        appointmentTable.setItems(inputList);
        appointmentTableAppointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        appointmentTableTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        appointmentTableDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        appointmentTableLocation.setCellValueFactory(new PropertyValueFactory<>("location"));
        appointmentTableContactName.setCellValueFactory(new PropertyValueFactory<>("contactName"));
        appointmentTableContactEmail.setCellValueFactory(new PropertyValueFactory<>("contactEmail"));
        appointmentTableType.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        appointmentTableStart.setCellValueFactory(new PropertyValueFactory<>("startDateTime"));
        appointmentTableEnd.setCellValueFactory(new PropertyValueFactory<>("endDateTime"));
        appointmentTableCustomerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        appointmentTableUserID.setCellValueFactory(new PropertyValueFactory<>("userID"));

    }

    /**
     * On action takes user to the Add Customer Screen
     * @param event
     * @throws IOException
     */
    public void onActionAddCustomer(ActionEvent event) throws IOException{
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/AddCustomer.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * On action takes user to the Update Customer Screen
     * @param event
     * @throws IOException
     * @throws SQLException
     */
    public void onActionUpdateCustomer(ActionEvent event) throws IOException, SQLException {
        Customer selectedCustomer = customerTable.getSelectionModel().getSelectedItem();

        if (selectedCustomer != null) {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/ModifyCustomer.fxml"));
            Parent parent = loader.load();
            Scene scene = new Scene(parent);
            ModifyCustomer controller = loader.getController();
            controller.customerForm(selectedCustomer);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.setScene(scene);
        }
        else{
            dialogBox(2);
        }
    }

    /**
     * On Action Deletes Selected Customer if no appointment is tied to it otherwise it notifies user to delete the appointments first
     * @param event
     * @throws SQLException
     */
    public void onActionDeleteCustomer(ActionEvent event) throws SQLException {
        Customer selectedCustomer = customerTable.getSelectionModel().getSelectedItem();

        if (selectedCustomer != null) {
            Alert alertConfirm = new Alert(Alert.AlertType.CONFIRMATION);
            alertConfirm.setTitle("Alert");
            alertConfirm.setHeaderText(null);
            alertConfirm.setContentText("Are you sure you want to delete \nCustomer ID: " + selectedCustomer.getCustomerID() + "?");
            Optional<ButtonType> result = alertConfirm.showAndWait();


            if (result.isPresent() && result.get() == ButtonType.OK) {
                if (AppointmentQuery.countCustomerAppointment(selectedCustomer.getCustomerID()) > 0) {
                    dialogBox(7);
                } else {
                    CustomerQuery.deleteCustomer(selectedCustomer.getCustomerID());
                    dialogBox(5);
                }
            } else {
                dialogBox(3);
            }
            try {
                customerTable(CustomerQuery.getAllCustomers());
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }
        else {
            dialogBox(2);
        }
    }

    /**
     * Default Selected radio button to view all data in the appointment table
     * @param actionEvent
     */
    public void onActionAllRadioButton(ActionEvent actionEvent) {

        try {
            ObservableList<Appointment> listOfAllAppointments = AppointmentQuery.getAllAppointments();
            appointmentTable(listOfAllAppointments);
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    /**
     * On action shows all the appointments for the current month
     * @param actionEvent
     * @throws SQLException
     */
    public void onActionMonthRadioButton(ActionEvent actionEvent) throws SQLException {

        ObservableList<Appointment> monthlyAppointments = FXCollections.observableArrayList();
        ObservableList<Appointment> listOfAllAppointments = AppointmentQuery.getAllAppointments();

        if (listOfAllAppointments == null) {
            System.out.println("An Error has Occurred - Month Radio Button");
        } else {
            // Get the start and end dates of the month
            LocalDateTime startOfTheMonth = LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
            LocalDateTime endOfTheMonth = startOfTheMonth.plusMonths(1);

            for (Appointment appointment : listOfAllAppointments) {
                // Check if the appointment falls within the current month
                LocalDateTime appointmentDateTime = appointment.getEndDateTime();
                if (appointmentDateTime.isAfter(startOfTheMonth) && appointmentDateTime.isBefore(endOfTheMonth)) {
                    monthlyAppointments.add(appointment);
                }
            }
            appointmentTable.setItems(monthlyAppointments);
        }
    }

    /**
     * On action shows all the appointments for the current week
     * @param actionEvent
     * @throws SQLException
     */
    public void onActionWeekRadioButton(ActionEvent actionEvent) throws SQLException {

        ObservableList<Appointment> weeklyAppointments = FXCollections.observableArrayList();
        ObservableList<Appointment> listOfAllAppointments = AppointmentQuery.getAllAppointments();

        // Get the start and end dates of the week
        LocalDate today = LocalDate.now();
        LocalDate startOfWeek = today.with(DayOfWeek.MONDAY);
        LocalDate endOfWeek = startOfWeek.plusDays(6);

        if (listOfAllAppointments == null) {
            System.out.println("An Error has Occurred - Week Radio Button");
        } else {
            for (Appointment appointment : listOfAllAppointments) {
                // Check if the appointment falls within the current week
                LocalDate appointmentDate = appointment.getStartDateTime().toLocalDate();
                if (appointmentDate.isEqual(startOfWeek) || appointmentDate.isAfter(startOfWeek)) {
                    if (appointmentDate.isEqual(endOfWeek) || appointmentDate.isBefore(endOfWeek)) {
                        weeklyAppointments.add(appointment);
                    }
                }
            }
            appointmentTable.setItems(weeklyAppointments);
        }
    }

    /**
     * On action takes user to the Add Appointment Screen
     * @param event
     * @throws IOException
     */
    public void onActionAddAppointment(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/AddAppointment.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * On action takes user to the Update Appointment Screen
     * @param event
     * @throws IOException
     * @throws SQLException
     */
    public void onActionUpdateAppointment(ActionEvent event) throws IOException, SQLException {

        Appointment selectedAppointment = appointmentTable.getSelectionModel().getSelectedItem();

        if (selectedAppointment != null) {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/ModifyAppointment.fxml"));
            Parent parent = loader.load();
            Scene scene = new Scene(parent);
            ModifyAppointment controller = loader.getController();
            controller.appointmentForm(selectedAppointment);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.setScene(scene);
        }
        else{
            dialogBox(8);
        }
    }

    /**
     * On action takes user to the Delete Appointment Screen
     * @param event
     * @throws SQLException
     */
    public void onActionDeleteAppointment(ActionEvent event) throws SQLException {
        Appointment selectedAppointment = appointmentTable.getSelectionModel().getSelectedItem();

        if (selectedAppointment != null) {
            Alert alertConfirm = new Alert(Alert.AlertType.CONFIRMATION);
            alertConfirm.setTitle("Alert");
            alertConfirm.setHeaderText(null);
            alertConfirm.setContentText("Are you sure you want to delete \nAppointment ID: " + selectedAppointment.getAppointmentID() + "\nAppointment Type: " + selectedAppointment.getAppointmentType()  + "?");
            Optional<ButtonType> result = alertConfirm.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                AppointmentQuery.deleteAppointment(selectedAppointment.getAppointmentID());
                dialogBox(6);
            }
            else{
                dialogBox(3);
            }
            try {
                appointmentTable(AppointmentQuery.getAllAppointments());
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }
        else {
            dialogBox(2);
        }
    }

    /**
     * On action asks user for confirmation if they would like to exit the application if yes application will exit,
     * if no it will notify that application did not exit
     * @param event
     */
    public void onActionExit(ActionEvent event) {
        Alert alertConfirm = new Alert(Alert.AlertType.CONFIRMATION);
        alertConfirm.setTitle("Alert");
        alertConfirm.setHeaderText(null);
        alertConfirm.setContentText("Are you sure you want to exit?");
        Optional<ButtonType> result = alertConfirm.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            System.exit(0);
        }
        else if(result.get() == ButtonType.CANCEL){
            dialogBox(1);
        }
    }

    /**
     * Displays dialog when method is called using the id.
     * @param dialogType
     */
    private void dialogBox(int dialogType) {
        Alert alertInfo = new Alert(Alert.AlertType.INFORMATION);
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        if (dialogType == 1) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText("Program did not Exit.");
            alertInfo.showAndWait();
        }else if (dialogType == 2) {
            alertError.setTitle("Error");
            alertError.setHeaderText(null);
            alertError.setHeaderText("No customer was selected.");
            alertError.showAndWait();
        }else if (dialogType == 3) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setContentText("item was not deleted.");
            alertInfo.showAndWait();
        }else if (dialogType == 4) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setContentText("item was deleted.");
            alertInfo.showAndWait();
        }else if (dialogType == 5) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setContentText("Customer was deleted.");
            alertInfo.showAndWait();
        }else if (dialogType == 6) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setContentText("Appointment was deleted.");
            alertInfo.showAndWait();
        }else if (dialogType == 7) {
            alertError.setTitle("Error");
            alertError.setHeaderText("Some Appointments are still associated to this Customer");
            alertError.setContentText("Please remove all associated Appointments before deleting a Customer.");
            alertError.showAndWait();
        } else if (dialogType == 8) {
            alertError.setTitle("Error");
            alertError.setHeaderText(null);
            alertError.setHeaderText("No Appointment was selected.");
            alertError.showAndWait();
        }
    }
}
