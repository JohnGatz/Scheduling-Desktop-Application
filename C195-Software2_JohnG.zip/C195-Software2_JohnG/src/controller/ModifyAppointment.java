package controller;

import Database.AppointmentQuery;
import Database.ContactQuery;
import Database.CustomerQuery;
import Database.UserQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller for ModifyAppointment
 * Modify Appointment and update selected appointment to the database after save user returns to main screen
 *
 * @author
 * John Gutierrez
 */

public class ModifyAppointment implements Initializable{

    @FXML
    private TextField appointmentIDTextField;

    @FXML
    private TextField titleTextField;

    @FXML
    private TextArea descriptionTextField;

    @FXML
    private TextField locationTextField;

    @FXML
    private ComboBox<String> contactComboBox;

    @FXML
    private TextField typeTextField;

    @FXML
    private DatePicker startDateSelectDate;

    @FXML
    private DatePicker endDateSelectDate;

    @FXML
    private ComboBox<String> startTimeComboBox;

    @FXML
    private ComboBox<String> endTimeComboBox;

    @FXML
    private ComboBox<Integer> customerIDComboBox;

    @FXML
    private ComboBox<Integer> userIDComboBox;

    Stage stage;
    Parent scene;

    /**
     * Loads data into the contact and Time comboboxes
     * | lambda is creating a list of contact names from the list of contacts from the database
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Contact> allContacts = null;
        try {
            allContacts = ContactQuery.getAllContacts();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        ObservableList<String> allContactsNames = FXCollections.observableArrayList();

        allContacts.forEach(contacts -> allContactsNames.add(contacts.getContactName()));

        // Set up the contact combo box
        contactComboBox.setItems(allContactsNames);
        contactComboBox.setEditable(true);
        contactComboBox.getEditor().setEditable(false);

        // Set up the start time and end time combo boxes
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        ObservableList<String> appointmentTimesDuringDay = FXCollections.observableArrayList();

        LocalTime firstAppointmentTimeLocalDateTime = LocalTime.of(8, 0, 0);
        LocalTime lastAppointmentTimeLocalDateTime = LocalTime.of(22, 30, 0);

        for (LocalTime time = firstAppointmentTimeLocalDateTime;
             time.isBefore(lastAppointmentTimeLocalDateTime);
             time = time.plusMinutes(30)) {
            appointmentTimesDuringDay.add(dateTimeFormatter.format(time));
        }

        startTimeComboBox.setItems(appointmentTimesDuringDay);
        startTimeComboBox.setEditable(true);
        startTimeComboBox.getEditor().setEditable(false);

        endTimeComboBox.setItems(appointmentTimesDuringDay);
        endTimeComboBox.setEditable(true);
        endTimeComboBox.getEditor().setEditable(false);

        // Retrieve list of all customer IDs and user IDs
        try {
            customerIDComboBox.setItems(CustomerQuery.getAllCustomerID());
            userIDComboBox.setItems(UserQuery.getAllUserID());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     loads selected Appointment data into form
     * @param selectedAppointment
     * @throws SQLException
     */
    public void appointmentForm(Appointment selectedAppointment) throws SQLException {

        appointmentIDTextField.setText(String.valueOf(selectedAppointment.getAppointmentID()));
        titleTextField.setText(selectedAppointment.getTitle());
        descriptionTextField.setText(selectedAppointment.getDescription());
        locationTextField.setText(selectedAppointment.getLocation());
        contactComboBox.setValue(selectedAppointment.getContactName());
        typeTextField.setText(selectedAppointment.getAppointmentType());
        startDateSelectDate.setValue(selectedAppointment.getStartDateTime().toLocalDate());
        endDateSelectDate.setValue(selectedAppointment.getEndDateTime().toLocalDate());
        startTimeComboBox.setValue(String.valueOf(selectedAppointment.getStartDateTime().toLocalTime()));
        endTimeComboBox.setValue(String.valueOf(selectedAppointment.getEndDateTime().toLocalTime()));
        customerIDComboBox.setValue(Integer.valueOf(String.valueOf(selectedAppointment.getCustomerID())));
        userIDComboBox.setValue(Integer.valueOf(String.valueOf(selectedAppointment.getUserID())));
    }

    /**
     * On Action Updates the data in the database and returns to the main screen
     * If anything on form is missing a requirement it will notify the user and stay on the form until it is corrected
     * @param event
     * @throws SQLException
     * @throws IOException
     */
    public void onActionSave(ActionEvent event) throws SQLException, IOException {
        Integer appointmentID = Integer.parseInt(appointmentIDTextField.getText());
        String title = titleTextField.getText();
        String description = descriptionTextField.getText();
        String location = locationTextField.getText();
        String contactName = contactComboBox.getValue();
        String type = typeTextField.getText();
        Integer customerID = customerIDComboBox.getValue();
        Integer userID = userIDComboBox.getValue();
        Integer contactID = ContactQuery.getContactID(contactName);

        // Get the list of all appointments
        ObservableList<Appointment> listOfAllAppointments = AppointmentQuery.getAllAppointments();

        // Get the start and end dates and times of the appointment
        String startDateOfAppointment = startDateSelectDate.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String startTimeOfAppointment = startTimeComboBox.getValue();
        String endDateOfAppointment = endDateSelectDate.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String endTimeOfAppointment = endTimeComboBox.getValue();

        // Convert the start and end times to UTC
        String startOfUTCTime = AppointmentQuery.estToUTC(startDateOfAppointment + " " + startTimeOfAppointment + ":00");
        String endOfUTCTime = AppointmentQuery.estToUTC(endDateOfAppointment + " " + endTimeOfAppointment + ":00");

        // Get the start and end times as LocalTime and LocalDateTime
        LocalTime startOfLocalTime = LocalTime.parse(startTimeComboBox.getValue(), DateTimeFormatter.ofPattern("HH:mm"));
        LocalTime endOfLocalTime = LocalTime.parse(endTimeComboBox.getValue(), DateTimeFormatter.ofPattern("HH:mm"));
        LocalDate localDateStart = LocalDate.parse(startDateOfAppointment);
        LocalDate localDateEnd = LocalDate.parse(endDateOfAppointment);
        LocalDateTime startOfDateTime = LocalDateTime.of(localDateStart, startOfLocalTime);
        LocalDateTime endOfDateTime = LocalDateTime.of(localDateEnd, endOfLocalTime);

        // Get the start and end times as ZonedDateTime objects
        ZoneId localTimeZone = ZoneId.systemDefault();
        ZonedDateTime startZoneDateTime = startOfDateTime.atZone(localTimeZone);
        ZonedDateTime endZoneDateTime = endOfDateTime.atZone(localTimeZone);

        // Convert the start and end times to EST
        ZoneId estTimeZone = ZoneId.of("America/New_York");
        ZonedDateTime startESTConversion = startZoneDateTime.withZoneSameInstant(estTimeZone);
        ZonedDateTime endESTConversion = endZoneDateTime.withZoneSameInstant(estTimeZone);

        // Get the start and end times as LocalTime objects in the EST time zone
        LocalTime startAppointmentOutsideHours = startESTConversion.toLocalTime();
        LocalTime endAppointmentOutsideHours = endESTConversion.toLocalTime();

        // Get the start and end days of the week in the EST time zone
        DayOfWeek startAppointmentOutsideDays = startESTConversion.toLocalDate().getDayOfWeek();
        DayOfWeek endAppointmentOutsideDays = endESTConversion.toLocalDate().getDayOfWeek();

        // Get the integer value of the start and end days of the week
        int intStartAppointmentOutsideDays = startAppointmentOutsideDays.getValue();
        int intEndAppointmentOutsideDays = endAppointmentOutsideDays.getValue();

        // Set the start and end of the work week
        int startOfWorkWeek = DayOfWeek.MONDAY.getValue();
        int endOfWorkWeek = DayOfWeek.FRIDAY.getValue();

        // Set the start and end times of the business hours in the EST time zone
        LocalTime startOfBusinessHoursEST = LocalTime.of(8, 0, 0);
        LocalTime endOfBusinessHoursEST = LocalTime.of(22, 0, 0);

        for (Appointment appointment: listOfAllAppointments) {

            LocalDateTime startDateTimeCheck = appointment.getStartDateTime();
            LocalDateTime endDateTimeCheck = appointment.getEndDateTime();
            //checks if appointment start and end time match an existing appointment
            if ((customerID == appointment.getCustomerID()) && (startOfDateTime.isEqual(startDateTimeCheck)) && (endOfDateTime.isEqual(endDateTimeCheck))) {
                dialogBox(9);
                return;
            }//checks if appointment start time are overlapping an appointment
            if ((customerID == appointment.getCustomerID()) && (startOfDateTime.isAfter(startDateTimeCheck)) && (startOfDateTime.isBefore(endDateTimeCheck))) {
                dialogBox(7);
                return;
            }//checks if appointment end time are overlapping an appointment
            if (customerID == appointment.getCustomerID() && (endOfDateTime.isAfter(startDateTimeCheck)) && (endOfDateTime.isBefore(endDateTimeCheck))) {
                dialogBox(8);
                return;
            }
            //Checks if Appointment times are overlapped between the start time and end time
            if ((customerID == appointment.getCustomerID()) && (endOfDateTime.isAfter(endDateTimeCheck)) && (startOfDateTime.isBefore(startDateTimeCheck)) ) {
                dialogBox(6);
                return;
            }
        }
        if (intStartAppointmentOutsideDays < startOfWorkWeek || intStartAppointmentOutsideDays > endOfWorkWeek || intEndAppointmentOutsideDays < startOfWorkWeek || intEndAppointmentOutsideDays > endOfWorkWeek) {
            dialogBox(5);
        }
        else if (startAppointmentOutsideHours.isBefore(startOfBusinessHoursEST) || startAppointmentOutsideHours.isAfter(endOfBusinessHoursEST) || endAppointmentOutsideHours.isBefore(startOfBusinessHoursEST) || endAppointmentOutsideHours.isAfter(endOfBusinessHoursEST)) {
            dialogBox(4);
        }
        else if (title.isEmpty() || description.isEmpty() || location.isEmpty() || type.isEmpty()) {
            dialogBox(2);
        }
        else {
            int rowsAffected = AppointmentQuery.updateAppointment(appointmentID, title, description, location, type, startOfUTCTime, endOfUTCTime, customerID, userID, contactID );
            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();

            if(rowsAffected > 0){
                System.out.println("Insert Successful");
            }
            else System.out.println("Insert Failed");
        }
    }

    /**
     * On action if user presses the cancel button it will need to confirm it if yes it will return to main screen,
     * if no it will notify user that application did not exit.
     * @param event
     * @throws IOException
     */
    public void onActionCancel(ActionEvent event) throws IOException {

        Alert alertConfirm = new Alert(Alert.AlertType.CONFIRMATION);
        alertConfirm.setTitle("Alert");
        alertConfirm.setHeaderText(null);
        alertConfirm.setContentText("Are you sure? This will cancel all fields and return to the Main Screen.");
        Optional<ButtonType> result = alertConfirm.showAndWait();

        if(result.get() == ButtonType.OK){
            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }
        else if(result.get() == ButtonType.CANCEL){
            dialogBox(1);
        }
    }

    /**
     * Displays dialog when method is called using the id.
     * @param dialogType
     */
    private void dialogBox(int dialogType) {
        Alert alertInfo = new Alert(Alert.AlertType.INFORMATION);
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        Alert alertConfirm = new Alert(Alert.AlertType.CONFIRMATION);
        if (dialogType == 1) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText("Program did not Exit.");
            alertInfo.showAndWait();
        }
        if (dialogType == 2) {
            alertInfo.setTitle("Error");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText("Cannot leave fields blank.");
            alertInfo.showAndWait();
        }if (dialogType == 3) {
            alertError.setTitle("Error");
            alertError.setHeaderText("Unable to add appointment");
            alertError.setContentText("Invalid values in text fields please revise.");
            alertError.showAndWait();
        }if (dialogType == 4) {
            alertError.setTitle("Error");
            alertError.setHeaderText("Unable to add time");
            alertError.setContentText("Outside of buisness hours (8am-10pm EST)");
            alertError.showAndWait();
        }if (dialogType == 5) {
            alertError.setTitle("Error");
            alertError.setHeaderText("Unable to add Day");
            alertError.setContentText("Day is outside of business operations (Monday-Friday)");
            alertError.showAndWait();
        }if (dialogType == 6) {
            alertConfirm.setTitle("Error");
            alertConfirm.setHeaderText("Unable to add Appointment");
            alertConfirm.setContentText("Appointment overlaps with existing appointment.");
            alertConfirm.showAndWait();
        }if (dialogType == 7) {
            alertConfirm.setTitle("Error");
            alertConfirm.setHeaderText("Unable to add Appointment");
            alertConfirm.setContentText("Start time overlaps with existing appointment.");
            alertConfirm.showAndWait();
        }if (dialogType == 8) {
            alertConfirm.setTitle("Error");
            alertConfirm.setHeaderText("Unable to add Appointment");
            alertConfirm.setContentText("End time overlaps with existing appointment.");
            alertConfirm.showAndWait();
        }if (dialogType == 9) {
            alertConfirm.setTitle("Error");
            alertConfirm.setHeaderText("Unable to add Appointment");
            alertConfirm.setContentText("Start and End Times Match an existing Appointment");
            alertConfirm.showAndWait();
        }
    }

}
