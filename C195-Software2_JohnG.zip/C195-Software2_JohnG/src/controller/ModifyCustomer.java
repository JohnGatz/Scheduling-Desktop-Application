package controller;

import Database.CustomerQuery;
import Database.DivisionQuery;
import Database.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller for ModifyCustomer
 * Modify Customer and update selected customer to the database after save user returns to main screen
 *
 * @author
 * John Gutierrez
 */

public class ModifyCustomer implements Initializable {

    @FXML
    private TextField customerIDTextField;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField addressTextField;

    @FXML
    private ComboBox<String> countryComboBox;

    @FXML
    private ComboBox<String> stateComboBox;

    @FXML
    private TextField postalCodeTextField;

    @FXML
    private TextField phoneTextField;

    Stage stage;
    Parent scene;

    /**
     * Adds Country and first level division data from the selected customer to the combo boxes
     * | lambda going through firstlvlDivs and getting countryID and division for each object and adding them into 3 different list based on country ID
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        countryComboBox.setOnAction(event -> {
            String newValue = countryComboBox.getValue();
            if (newValue == null) {
                stateComboBox.getItems().clear();
                stateComboBox.setDisable(true);
            } else {
                try {
                    stateComboBox.setDisable(false);
                    stateComboBox.setItems(CustomerQuery.getFirstLevelDivisionsByCountry(newValue));
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void onActionCountryDropDown(ActionEvent event){
        try {
            JDBC.openConnection();
            ObservableList<String> firstLvlDivCountryUS = FXCollections.observableArrayList();
            ObservableList<String> firstLvlDivCountryUK = FXCollections.observableArrayList();
            ObservableList<String> firstLvlDivCountryCanada = FXCollections.observableArrayList();
            ObservableList<DivisionQuery> listOfAllFirstLvlDivs = DivisionQuery.getAllFirstLevelDivisions();

            String selectedCountry = countryComboBox.getSelectionModel().getSelectedItem();
            //lambda
            listOfAllFirstLvlDivs.forEach(firstLevelDivision -> {
                int countryId = firstLevelDivision.getCountryID();
                String division = firstLevelDivision.getDivision();
                switch (countryId) {
                    case 1:
                        firstLvlDivCountryUS.add(division);
                        break;
                    case 2:
                        firstLvlDivCountryUK.add(division);
                        break;
                    case 3:
                        firstLvlDivCountryCanada.add(division);
                        break;
                    default:
                        break;
                }
            });

            switch (selectedCountry) {
                case "U.S":
                    stateComboBox.setItems(firstLvlDivCountryUS);
                    System.out.println("U.S is Selected");
                    break;
                case "UK":
                    stateComboBox.setItems(firstLvlDivCountryUK);
                    System.out.println("UK is Selected");
                    break;
                case "Canada":
                    stateComboBox.setItems(firstLvlDivCountryCanada);
                    System.out.println("Canada is Selected");
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * loads selected customer data into form
     * @param selectedCustomer
     * @throws SQLException
     */
    public void customerForm(Customer selectedCustomer) throws SQLException {

        customerIDTextField.setText(selectedCustomer.getCustomerID().toString());
        nameTextField.setText(selectedCustomer.getName());
        addressTextField.setText(selectedCustomer.getAddress());
        countryComboBox.setItems(CustomerQuery.getAllCountries());
        countryComboBox.getSelectionModel().select(selectedCustomer.getCountry());
        stateComboBox.setItems(CustomerQuery.getFirstLevelDivisionsByCountry(selectedCustomer.getCountry()));
        stateComboBox.getSelectionModel().select(selectedCustomer.getDivision());
        postalCodeTextField.setText(selectedCustomer.getPostalCode());
        phoneTextField.setText(selectedCustomer.getPhone());

    }

    /**
     * On Action updates the data in the database and returns to the main screen
     * If anything on form is empty display error message
     * @param event
     */
    public void onActionSave(ActionEvent event) {

        try {
            Integer customerID = Integer.parseInt(customerIDTextField.getText());
            String name = nameTextField.getText();
            String address = addressTextField.getText();
            String country = countryComboBox.getValue();
            String division = stateComboBox.getValue();
            String postalCode = postalCodeTextField.getText();
            String phone = phoneTextField.getText();

            if (name.isEmpty() || country.isEmpty() || division.isEmpty() || address.isEmpty() || postalCode.isEmpty() || phone.isEmpty()) {
                dialogBox(2);
            }
            else{
                int rowsAffected = CustomerQuery.updateCustomer(name, address, postalCode, phone, division, customerID);
                stage = (Stage)((Button)event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
                System.out.println("update worked");

                if(rowsAffected > 0){
                    System.out.println("Insert Successful");
                }
                else System.out.println("Insert Failed");
            }
        }
        catch(Exception e) {
            dialogBox(3);
        }
    }

    /**
     * On action if user presses the cancel button it will need to confirm it if yes it will return to main screen,
     * if no it will notify user that application did not exit.
     * @param event
     * @throws IOException
     */
    public void onActionCancel(ActionEvent event) throws IOException {

        Alert alertConfirm = new Alert(Alert.AlertType.CONFIRMATION);
        alertConfirm.setTitle("Alert");
        alertConfirm.setHeaderText(null);
        alertConfirm.setContentText("Are you sure? This will cancel all fields and return to the Main Screen.");
        Optional<ButtonType> result = alertConfirm.showAndWait();

        if(result.get() == ButtonType.OK){
            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }
        else if(result.get() == ButtonType.CANCEL){
            dialogBox(1);
        }
    }

    /**
     * Displays dialog when method is called using the id.
     * @param dialogType
     */
    private void dialogBox(int dialogType) {
        Alert alertInfo = new Alert(Alert.AlertType.INFORMATION);
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        if (dialogType == 1) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText("Program did not Exit.");
            alertInfo.showAndWait();
        }
        if (dialogType == 2) {
            alertInfo.setTitle("Error");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText("Cannot leave fields blank.");
            alertInfo.showAndWait();
        }if (dialogType == 3) {
            alertError.setTitle("Error");
            alertError.setHeaderText("Unable to add Customer");
            alertError.setContentText("Invalid values in text fields please revise.");
            alertError.showAndWait();
        }
    }
}
