package controller;

import Database.AppointmentQuery;
import Database.ContactQuery;
import Database.ReportQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.time.Month;
import java.util.Collections;
import java.util.Optional;

//Combined all report models

/**
 * Controller for ReportForm
 * Shows User tables for number of customer appointments by Month, Type, Contacts, and Countries
 *
 * @author
 * John Gutierrez
 */

public class Report {


    @FXML
    private TableView <ReportByMonth> appointmentTableByMonth;

    @FXML
    private TableColumn <Customer, String>appointmentTableMonth;

    @FXML
    private TableColumn <Customer, String>appointmentTableMonthTotal;

    @FXML
    private TableView <ReportByType> appointmentTableByType;

    @FXML
    private TableColumn <Customer, String>appointmentTableType;

    @FXML
    private TableColumn <Customer, String>appointmentTableTypeTotal;

    @FXML
    private ComboBox <String> appointmentByContactTableComboBox;

    @FXML
    private TableView <Appointment> appointmentByContactTable;

    @FXML
    private TableColumn <Customer, Integer> appointmentTableContactAppointmentID;

    @FXML
    private TableColumn <Customer, String> appointmentTableContactTitle;

    @FXML
    private TableColumn <Customer, String> appointmentTableContactDescription;


    @FXML
    private TableColumn <Customer, String> appointmentTableContactType;

    @FXML
    private TableColumn <Customer, String> appointmentTableContactStart;

    @FXML
    private TableColumn <Customer, String> appointmentTableContactEnd;

    @FXML
    private TableColumn <Customer, String> appointmentTableContactCustomerID;

    @FXML
    private TableColumn <Customer, String> appointmentTableContactID;

    @FXML
    private TableView <ReportByCountry> appointmentTableByCountry;

    @FXML
    private TableColumn <Customer, String> appointmentTableCountry;

    @FXML
    private TableColumn <Customer, String> appointmentTableCountryTotal;

    Stage stage;
    Parent scene;

    /**
     * loads the all data into the tables
     * @throws SQLException
     */
    public void initialize() throws SQLException {
        AppointmentByMonthTable();
        AppointmentByTypeTable();
        AppointmentByContactTable();
        AppointmentByCountryTable();
        appointmentTableByMonth();
        appointmentTableByType();
        appointmentTableByCountry();


        //loads contact names into combo box
        ObservableList<String> allContactsNames = FXCollections.observableArrayList();
        ObservableList<Contact> allContacts = ContactQuery.getAllContacts();
        allContacts.forEach(contacts -> allContactsNames.add(contacts.getContactName()));
        appointmentByContactTableComboBox.setItems(allContactsNames);
    }

    /**
     * Appointment By month table
     */
    public void AppointmentByMonthTable(){
        appointmentTableMonth.setCellValueFactory(new PropertyValueFactory<>("appointmentMonth"));
        appointmentTableMonthTotal.setCellValueFactory(new PropertyValueFactory<>("appointmentMonthTotal"));
    }

    /**
     * Appointment By Type table
     */
    public void AppointmentByTypeTable(){
        appointmentTableType.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        appointmentTableTypeTotal.setCellValueFactory(new PropertyValueFactory<>("appointmentTypeTotal"));
    }

    /**
     * appointment by contact table
     */
    public void AppointmentByContactTable(){
        appointmentTableContactAppointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        appointmentTableContactTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        appointmentTableContactDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        appointmentTableContactType.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        appointmentTableContactStart.setCellValueFactory(new PropertyValueFactory<>("startDateTime"));
        appointmentTableContactEnd.setCellValueFactory(new PropertyValueFactory<>("endDateTime"));
        appointmentTableContactCustomerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
    }

    /**
     * Appointment by Country Table
     */
    public void AppointmentByCountryTable(){
        appointmentTableCountry.setCellValueFactory(new PropertyValueFactory<>("countryName"));
        appointmentTableCountryTotal.setCellValueFactory(new PropertyValueFactory<>("countryCount"));
    }

    /**
     * Loads appointment by month table and sets it by total number of appointments per month
     * @throws SQLException
     */
    public void appointmentTableByMonth() throws SQLException {

        ObservableList<ReportByMonth> monthlyReports = FXCollections.observableArrayList();
        ObservableList<Month> appointmentMonths = FXCollections.observableArrayList();
        ObservableList<Appointment> allAppointments = AppointmentQuery.getAllAppointments();

        for (Appointment appointment : allAppointments) {
            appointmentMonths.add(appointment.getStartDateTime().getMonth());
        }

        ObservableList<Month> appointmentReportsByCurrentMonth = FXCollections.observableArrayList();
        for (Month month : appointmentMonths) {
            if (!appointmentReportsByCurrentMonth.contains(month)) {
                appointmentReportsByCurrentMonth.add(month);
            }
        }

        for (Month month : appointmentReportsByCurrentMonth) {
            int totalMonth = Collections.frequency(appointmentMonths, month);
            String monthName = month.name();
            ReportByMonth appointmentMonth = new ReportByMonth(monthName, totalMonth);
            monthlyReports.add(appointmentMonth);
        }

        appointmentTableByMonth.setItems(monthlyReports);
    }

/**
 * Loads appointment by Type table and sets it by total number of appointments by type
 * @throws SQLException
 */
    private void appointmentTableByType() throws SQLException {

        ObservableList<Appointment> allAppointments = AppointmentQuery.getAllAppointments();
        ObservableList<ReportByType> reportType = FXCollections.observableArrayList();

        ObservableList<String> appointmentReportsByType = FXCollections.observableArrayList();
        ObservableList<String> appointmentByType = FXCollections.observableArrayList();

        for (Appointment appointment : allAppointments) {
            String appointmentType = appointment.getAppointmentType();
            appointmentByType.add(appointmentType);
            if (!appointmentReportsByType.contains(appointmentType)) {
                appointmentReportsByType.add(appointmentType);
            }
        }

        for (String type : appointmentReportsByType) {
            int typeTotal = 0;
            for (String appointmentType : appointmentByType) {
                if (appointmentType.equals(type)) {
                    typeTotal++;
                }
            }
            ReportByType appointmentTypes = new ReportByType(type, typeTotal);
            reportType.add(appointmentTypes);
        }

        appointmentTableByType.setItems(reportType);
    }

    /**
     * User chooses contact from the combo boxes it will load data into the Appointment by contact table
     * @throws SQLException
     */
    @FXML
    public void onActionContactComboBox() throws SQLException {

        ObservableList<Contact> listOfContacts = ContactQuery.getAllContacts();
        ObservableList<Appointment> listOfAllAppointmentData = AppointmentQuery.getAllAppointments();
        ObservableList<Appointment> appointmentData = FXCollections.observableArrayList();

        String contactName = appointmentByContactTableComboBox.getSelectionModel().getSelectedItem();
        Contact selectedContact = null;
        for (Contact contact : listOfContacts) {
            if (contact.getContactName().equals(contactName)) {
                selectedContact = contact;
                break;
            }
        }

        if (selectedContact != null) {
            for (Appointment appointment : listOfAllAppointmentData) {
                if (appointment.getContactID() == selectedContact.getContactID()) {
                    appointmentData.add(appointment);
                }
            }
        }
        appointmentByContactTable.setItems(appointmentData);
    }

    /**
     * Loads appointment by Country table and sets it by total number of appointments by Country
     * @throws SQLException
     */
    public void appointmentTableByCountry() throws SQLException {

        ObservableList<ReportByCountry> countriesToAdd = ReportQuery.getAllCountries();
        appointmentTableByCountry.setItems(countriesToAdd);
    }

    /**
     * On action takes user back to the Main Screen
     * @param event
     * @throws IOException
     */
    public void onActionBackToMainMenu(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * On action asks user for confirmation if they would like to exit the application if yes application will exit,
     * if no it will notify that application did not exit
     * @param event
     */
    public void onActionExit(ActionEvent event) {
        Alert alertConfirm = new Alert(Alert.AlertType.CONFIRMATION);
        alertConfirm.setTitle("Alert");
        alertConfirm.setHeaderText(null);
        alertConfirm.setContentText("Are you sure you want to exit?");
        Optional<ButtonType> result = alertConfirm.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            System.exit(0);
        }
        else if(result.get() == ButtonType.CANCEL){
            dialogBox(1);
        }
    }

    /**
     * Displays dialog when method is called using the id.
     * @param dialogType
     */
    private void dialogBox(int dialogType) {
        Alert alertInfo = new Alert(Alert.AlertType.INFORMATION);
        if (dialogType == 1) {
            alertInfo.setTitle("Information");
            alertInfo.setHeaderText(null);
            alertInfo.setHeaderText("Program did not Exit.");
            alertInfo.showAndWait();
        }
    }
}
