package model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Model for Appointment
 *
 * @author
 * John Gutierrez
 */
public class Appointment {
    private int appointmentID;
    private String title;
    private String description;
    private String location;
    private String appointmentType;
    private LocalDateTime startDateTime;
    private LocalDateTime endDateTime;
    private Timestamp createDate;
    private Timestamp lastUpdateDateTime;
    private int customerID;
    private int userID;
    private int contactID;
    private String contactName;
    private String contactEmail;

    /**
     *
     * @param appointmentID
     * @param title
     * @param description
     * @param location
     * @param appointmentType
     * @param startDateTime
     * @param endDateTime
     * @param createDate
     * @param lastUpdateDateTime
     * @param customerID
     * @param userID
     * @param contactID
     * @param contactName
     * @param contactEmail
     */
    public Appointment(Integer appointmentID, String title, String description, String location, String appointmentType, LocalDateTime startDateTime,
                       LocalDateTime endDateTime, Timestamp createDate, Timestamp lastUpdateDateTime, Integer customerID, Integer userID,
                       Integer contactID, String contactName, String contactEmail) {
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.appointmentType = appointmentType;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.createDate = createDate;
        this.lastUpdateDateTime = lastUpdateDateTime;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
        this.contactName = contactName;
        this.contactEmail = contactEmail;
    }

    /**
     *
     * @return appointmentID
     */
    public Integer getAppointmentID() {
        return appointmentID;
    }

    /**
     *
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     *
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @return location
     */
    public String getLocation() {
        return location;
    }
    /**
     *
     * @return appointmentType
     */
    public String getAppointmentType() {
        return appointmentType;
    }

    /**
     *
     * @return startDateTime
     */
    public LocalDateTime getStartDateTime() {
        return startDateTime;
    }
    /**
     *
     * @return endDateTime
     */
    public LocalDateTime getEndDateTime() {
        return endDateTime;
    }
    /**
     *
     * @return createDate
     */
    public Timestamp getCreateDate() {
        return createDate;
    }
    /**
     *
     * @return lastUpdateDateTime
     */
    public Timestamp getLastUpdateDateTime() {
        return lastUpdateDateTime;
    }
    /**
     *
     * @return customerID
     */
    public int getCustomerID() {
        return customerID;
    }
    /**
     *
     * @return userID
     */
    public int getUserID() {
        return userID;
    }
    /**
     *
     * @return contactID
     */
    public int getContactID() {
        return contactID;
    }
    /**
     *
     * @return contactName
     */
    public String getContactName() {
        return contactName;
    }
    /**
     *
     * @return contactEmail
     */
    public String getContactEmail() {
        return contactEmail;
    }


}
