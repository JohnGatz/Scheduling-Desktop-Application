package model;

/**
 * Model for Contact
 *
 * @author
 * John Gutierrez
 */
public class Contact {
    private int contactID;
    private String contactName;
    private String contactEmail;

    /**
     *
     * @param contactID
     * @param contactName
     * @param contactEmail
     */
    public Contact(int contactID, String contactName, String contactEmail) {
        this.contactID = contactID;
        this.contactName = contactName;
        this.contactEmail = contactEmail;
    }

    /**
     *
     * @return contactID
     */
    public int getContactID() {
        return contactID;
    }

    /**
     *
     * @return contactName
     */
    public String getContactName() {return contactName;
    }
    /**
     *
     * @return contactEmail
     */
    public String getContactEmail() {
        return contactEmail;
    }
}
