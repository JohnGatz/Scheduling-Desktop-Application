package model;

import javafx.collections.ObservableList;

/**
 * Model for Customer
 *
 * @author
 * John Gutierrez
 */
public class Customer {
    private int customerID;
    private String Name;
    private String Address;
    private String Country;
    private String Division;
    private String PostalCode;
    private String Phone;
    private int divisionID;

    /**
     *
     * @param customerID
     * @param name
     * @param address
     * @param country
     * @param division
     * @param postalCode
     * @param phone
     * @param divisionID
     */
    public Customer(int customerID, String name, String address, String country, String division, String postalCode, String phone, int divisionID) {
        this.customerID = customerID;
        this.Name = name;
        this.Address = address;
        this.Country = country;
        this.Division = division;
        this.PostalCode = postalCode;
        this.Phone = phone;
        this.divisionID = divisionID;

    }

    /**
     *
     * @return customerID
     */
    public Integer getCustomerID() {
        return customerID;
    }

    /**
     *
     * @param customerID
     */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /**
     *
     * @return Name
     */
    public String getName() {
        return Name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        Name = name;
    }

    /**
     *
     * @return Address
     */
    public String getAddress() {
        return Address;
    }

    /**
     *
     * @param address
     */
    public void setAddress(String address) {
        Address = address;
    }

    /**
     *
     * @return Division
     */
    public String getDivision() {return Division;
    }

    /**
     *
     * @return Division
     */
    public String setDivision() {return Division;}

    /**
     *
     * @return Country
     */
    public String getCountry() {
        return Country;
    }

    /**
     *
     * @return Country
     */
    public String setCountry() {return Country;}

    /**
     *
     * @return PostalCode
     */
    public String getPostalCode() {
        return PostalCode;
    }

    /**
     *
     * @param postalCode
     */
    public void setPostalCode(String postalCode) {
        PostalCode = postalCode;
    }

    /**
     *
     * @return Phone
     */
    public String getPhone() {
        return Phone;
    }

    /**
     *
     * @param phone
     */
    public void setPhone(String phone) {
        Phone = phone;
    }

    /**
     *
     * @return divisionID
     */
    public int getDivisionID() {
        return divisionID;
    }

    /**
     *
     * @param divisionID
     */
    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }
}
