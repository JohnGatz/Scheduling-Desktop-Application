package model;

/**
 * Model for First Level Division
 *
 * @author
 * John Gutierrez
 */
public class FirstLevelDivision {
    private int divisionID;
    private String division;
    private int countryID;

    /**
     *
     * @param divisionID
     * @param division
     * @param countryID
     */
    public FirstLevelDivision(int divisionID, String division, int countryID) {
        this.divisionID = divisionID;
        this.division = division;
        this.countryID = countryID;
    }

    /**
     *
     * @return divisionID
     */
    public int getDivisionID() {
        return divisionID;
    }

    /**
     *
     * @return division
     */
    public String getDivision() {
        return division;
    }

    /**
     *
     * @return countryID
     */
    public int getCountryID() {
        return countryID;
    }
}
