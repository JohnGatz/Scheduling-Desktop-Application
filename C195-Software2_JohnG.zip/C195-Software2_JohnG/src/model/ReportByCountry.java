package model;

/**
 * Model for ReportForm Country
 *
 * @author
 * John Gutierrez
 */
public class ReportByCountry {

    private String countryName;
    private int countryTotal;

    /**
     *
     * @param countryName
     * @param countryTotal
     */
    public ReportByCountry(String countryName, int countryTotal) {
        this.countryName = countryName;
        this.countryTotal = countryTotal;

    }

    /**
     *
     * @return countryName
     */
    public String getCountryName() {

        return countryName;
    }

    /**
     *
     * @return countryTotal
     */
    public int getCountryCount() {

        return countryTotal;
    }
}
