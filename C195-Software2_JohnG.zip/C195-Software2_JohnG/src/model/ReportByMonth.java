package model;

/**
 * Model for ReportForm Month
 *
 * @author
 * John Gutierrez
 */
public class ReportByMonth {

    public String appointmentMonth;

    public int appointmentMonthTotal;

    /**
     *
     * @param appointmentMonth
     * @param appointmentMonthTotal
     */
    public ReportByMonth(String appointmentMonth, int appointmentMonthTotal) {
        this.appointmentMonth = appointmentMonth;
        this.appointmentMonthTotal = appointmentMonthTotal;
    }

    /**
     *
     * @return appointmentMonth
     */
    public String getAppointmentMonth() {
        return appointmentMonth;
    }

    /**
     *
     * @return appointmentMonthTotal
     */
    public int getAppointmentMonthTotal() {
        return appointmentMonthTotal;
    }
}
