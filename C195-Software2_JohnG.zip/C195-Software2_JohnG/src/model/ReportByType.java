package model;

/**
 * Model for ReportForm Type
 *
 * @author
 * John Gutierrez
 */
public class ReportByType {

    public String appointmentType;

    public int appointmentTypeTotal;

    /**
     *
     * @param appointmentType
     * @param appointmentTypeTotal
     */
    public ReportByType(String appointmentType, int appointmentTypeTotal) {
        this.appointmentType = appointmentType;
        this.appointmentTypeTotal = appointmentTypeTotal;
    }

    /**
     *
     * @return appointmentType
     */
    public String getAppointmentType() {
        return appointmentType;
    }

    /**
     *
     * @return appointmentTypeTotal
     */
    public int getAppointmentTypeTotal() {
        return appointmentTypeTotal;
    }
}
