package model;

/**
 * Model for User
 *
 * @author
 * John Gutierrez
 */
public class User {
    private int userID;
    private String username;
    private String password;

    /**
     *
     * @param userID
     * @param username
     * @param password
     */
    public User(int userID, String username, String password) {
        this.userID = userID;
        this.username = username;
        this.password = password;
    }

    /**
     *
     * @return userID
     */
    public int getUserID() {
        return userID;
    }

    /**
     *
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @return password
     */
    public String getPassword() {
        return password;
    }
}
